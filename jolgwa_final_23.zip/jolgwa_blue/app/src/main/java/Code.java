public class Code {
    public static int requestCode = 100;
    public static int resultCode = 1;
}